/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  MapPin, 
  Plus, 
  User as UserIcon, 
  ShoppingBag, 
  ArrowLeft, 
  Store, 
  Phone,
  MessageCircle,
  LogOut,
  Camera,
  CheckCircle2,
  PackageSearch
} from 'lucide-react';
import { cn, formatCurrency } from './lib/utils';
import { Product, CATEGORIES, UserRole, UserProfile } from './types';
import imageCompression from 'browser-image-compression';
import { generateProductDescription } from './lib/gemini';

// --- Types ---
type View = 'splash' | 'auth' | 'buyer_home' | 'artisan_home' | 'product_detail' | 'upload';

// --- Components ---

const Splash = ({ onFinish }: { onFinish: () => void }) => {
  useEffect(() => {
    const timer = setTimeout(onFinish, 2500);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <motion.div 
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-primary overflow-hidden"
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="text-center"
      >
        <div className="w-32 h-32 bg-secondary rounded-[40px] flex items-center justify-center mx-auto mb-6 shadow-2xl rotate-12">
          <Store className="w-16 h-16 text-white -rotate-12" />
        </div>
        <h1 className="text-4xl font-display font-bold text-white mb-2">Halli-Santhe</h1>
        <p className="text-white/80 tracking-widest uppercase text-sm font-medium">Digital Marketplace</p>
      </motion.div>
      <div className="absolute bottom-12 left-0 right-0 text-center">
        <p className="text-white/60 text-xs font-medium">Vocal for Local • Atma Nirbhar</p>
      </div>
    </motion.div>
  );
};

const Auth = ({ onLogin }: { onLogin: (role: UserRole) => void }) => {
  const [role, setRole] = useState<UserRole | null>(null);

  return (
    <div className="min-h-screen bg-background p-6 flex flex-col">
      <div className="flex-1 flex flex-col justify-center">
        <h2 className="text-3xl font-display font-bold text-maroon mb-2">Namaste! 🙏</h2>
        <p className="text-zinc-600 mb-12">Join our vibrant local community.</p>

        {!role ? (
          <div className="space-y-4">
            <button 
              onClick={() => setRole('artisan')}
              className="w-full market-card flex items-center p-6 gap-4 hover:border-primary active:bg-primary/5 transition-all text-left"
            >
              <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
                <Store className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg">I am an Artisan</h3>
                <p className="text-sm text-zinc-500">I want to sell my handmade crafts.</p>
              </div>
            </button>
            <button 
              onClick={() => setRole('buyer')}
              className="w-full market-card flex items-center p-6 gap-4 hover:border-secondary active:bg-secondary/5 transition-all text-left"
            >
              <div className="w-12 h-12 bg-secondary/10 rounded-2xl flex items-center justify-center text-secondary">
                <ShoppingBag className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg">I am a Buyer</h3>
                <p className="text-sm text-zinc-500">I want to discover local treasures.</p>
              </div>
            </button>
          </div>
        ) : (
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            <div className="flex items-center gap-2 mb-6">
               <button onClick={() => setRole(null)} className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></button>
               <span className="font-medium">Selected: {role.charAt(0).toUpperCase() + role.slice(1)}</span>
            </div>
            <input type="text" placeholder="Your Name" className="w-full input-field" />
            <input type="tel" placeholder="Phone Number" className="w-full input-field" />
            <button 
              onClick={() => onLogin(role)}
              className="w-full btn-primary mt-4"
            >
              Start Exploring
            </button>
          </motion.div>
        )}
      </div>
    </div>
  );
};

const ProductCard = ({ product, onClick }: { product: Product, onClick: () => void }) => {
  return (
    <motion.div 
      layoutId={`card-${product.id}`}
      onClick={onClick}
      className="market-card p-0 flex flex-col overflow-hidden bg-white h-full"
    >
      <div className="aspect-square w-full relative">
        <img 
          src={product.imageUrl} 
          alt={product.name}
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg text-[10px] font-bold text-accent shadow-sm">
          {product.category.toUpperCase()}
        </div>
      </div>
      <div className="p-3 flex-1 flex flex-col">
        <h3 className="font-bold text-sm text-zinc-800 line-clamp-1">{product.name}</h3>
        <p className="text-xs text-zinc-500 mb-2">{product.artisanName}</p>
        <div className="mt-auto flex items-center justify-between">
          <span className="text-primary font-bold">{formatCurrency(product.price)}</span>
          <div className="w-8 h-8 rounded-full bg-secondary/10 flex items-center justify-center text-secondary">
             <Plus className="w-4 h-4" />
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default function App() {
  const [view, setView] = useState<View>('splash');
  const [user, setUser] = useState<UserProfile | null>(null);
  const [products, setProducts] = useState<Product[]>([
    {
      id: '1',
      name: 'Mysore Silk Saree',
      description: 'Authentic pure Mysore silk saree handcrafted with gold zari borders. Perfect for traditional occasions.',
      category: 'textiles',
      price: 12500,
      imageUrl: 'https://images.unsplash.com/photo-1610030469614-2e9949646452?auto=format&fit=crop&q=80&w=400',
      artisanId: 'artisan_1',
      artisanName: 'Venkatesh S.',
      artisanPhone: '+919988776655',
      status: 'available',
      createdAt: Date.now()
    },
    {
      id: '2',
      name: 'Bidriware Vase',
      description: 'Exquisite Bidriware flower vase from Bidar. Zinc and copper alloy with fine silver inlay work.',
      category: 'other',
      price: 3200,
      imageUrl: 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&q=80&w=400',
      artisanId: 'artisan_2',
      artisanName: 'Mohammad A.',
      artisanPhone: '+918877665544',
      status: 'available',
      createdAt: Date.now()
    },
    {
        id: '3',
        name: 'Channapatna Toys',
        description: 'Traditional wooden toys colored with safe vegetable dyes. A legacy of Tipu Sultan era.',
        category: 'woodwork',
        price: 850,
        imageUrl: 'https://images.unsplash.com/photo-1544208062-30225d31518f?auto=format&fit=crop&q=80&w=400',
        artisanId: 'artisan_3',
        artisanName: 'Babu Rao',
        artisanPhone: '+917766554433',
        status: 'available',
        createdAt: Date.now()
      }
  ]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [compressedFile, setCompressedFile] = useState<File | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isUploading, setIsUploading] = useState(false);

  // --- Handlers ---
  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const options = {
        maxSizeMB: 1,
        maxWidthOrHeight: 1280,
        useWebWorker: true,
      };
      
      const compressedBlob = await imageCompression(file, options);
      const output = new File([compressedBlob], file.name, { type: file.type });
      setCompressedFile(output);
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result as string);
      };
      reader.readAsDataURL(output);
    } catch (error) {
      console.error('Compression error:', error);
    }
  };

  const handleLogin = (role: UserRole) => {
    const newUser: UserProfile = {
      uid: 'mock_uid',
      email: 'test@example.com',
      role,
      displayName: role === 'artisan' ? 'Ramesh Artisan' : 'Sumit Buyer',
      phone: '9876543210',
      createdAt: Date.now()
    };
    setUser(newUser);
    setView(role === 'artisan' ? 'artisan_home' : 'buyer_home');
  };

  const handleUpload = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsUploading(true);
    const formData = new FormData(e.currentTarget);
    
    // In a real app, logic for image upload to Firebase Storage would go here
    // Mocking the result for now
    const newProduct: Product = {
      id: Math.random().toString(36).substr(2, 9),
      name: formData.get('name') as string,
      description: formData.get('description') as string,
      category: formData.get('category') as string,
      price: Number(formData.get('price')),
      imageUrl: previewImage || 'https://images.unsplash.com/photo-1544027993-37dbfe43562a?auto=format&fit=crop&q=80&w=400', 
      artisanId: user!.uid,
      artisanName: user!.displayName,
      artisanPhone: user!.phone,
      status: 'available',
      createdAt: Date.now()
    };

    setProducts([newProduct, ...products]);
    setPreviewImage(null);
    setCompressedFile(null);
    setIsUploading(false);
    setView('artisan_home');
  };

  // --- Filtered Products ---
  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="max-w-md mx-auto min-h-screen bg-background shadow-2xl relative flex flex-col font-sans">
      <AnimatePresence mode="wait">
        {view === 'splash' && <Splash onFinish={() => setView('auth')} />}
      </AnimatePresence>

      <main className="flex-1 overflow-y-auto">
        {view === 'auth' && <Auth onLogin={handleLogin} />}

        {view === 'buyer_home' && (
          <div className="p-6 pb-24">
            <header className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-2xl text-maroon">Local Santhe</h1>
                <p className="text-zinc-500 text-xs flex items-center gap-1">
                  <MapPin className="w-3 h-3" /> Karnataka, India
                </p>
              </div>
              <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-white shadow-sm">
                <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.displayName}`} alt="Profile" />
              </div>
            </header>

            {/* Search */}
            <div className="relative mb-6">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
              <input 
                type="text" 
                placeholder="Search local products..." 
                className="w-full pl-12 pr-4 py-4 bg-white rounded-2xl shadow-sm border border-zinc-100 focus:outline-none focus:ring-2 focus:ring-primary/20"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Categories */}
            <div className="flex overflow-x-auto gap-3 pb-4 mb-6 -mx-6 px-6 no-scrollbar">
              <button 
                onClick={() => setSelectedCategory('all')}
                className={cn("px-5 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all", 
                  selectedCategory === 'all' ? "bg-primary text-white" : "bg-white text-zinc-500 shadow-sm border border-zinc-100")}
              >All Categories</button>
              {CATEGORIES.map(cat => (
                <button 
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={cn("px-5 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all flex items-center gap-2", 
                    selectedCategory === cat.id ? "bg-primary text-white" : "bg-white text-zinc-500 shadow-sm border border-zinc-100")}
                >
                  <span>{cat.icon}</span>
                  {cat.name}
                </button>
              ))}
            </div>

            {filteredProducts.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <div className="w-48 h-48 bg-zinc-100 rounded-full flex items-center justify-center mb-6">
                   <PackageSearch className="w-24 h-24 text-zinc-300" />
                </div>
                <h3 className="text-xl font-bold text-zinc-800">No products available yet</h3>
                <p className="text-zinc-500 mt-2 max-w-[200px]">We are waiting for artisans to showcase their work.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {filteredProducts.map(p => (
                  <ProductCard 
                    key={p.id} 
                    product={p} 
                    onClick={() => {
                        setSelectedProduct(p);
                        setView('product_detail');
                    }} 
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {view === 'artisan_home' && (
          <div className="p-6 pb-24">
             <header className="flex items-center justify-between mb-8">
              <h1 className="text-2xl text-maroon">Artisan Studio</h1>
              <button onClick={() => setView('auth')} className="p-2 text-zinc-400"><LogOut className="w-5 h-5" /></button>
            </header>

            <div className="market-card bg-primary/5 border-primary/20 p-6 mb-8 text-center flex flex-col items-center">
               <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-primary shadow-sm mb-4">
                 <Store className="w-8 h-8" />
               </div>
               <h2 className="text-lg font-bold">Welcome back, {user?.displayName}</h2>
               <p className="text-sm text-zinc-500 mt-1">Ready to showcase something new?</p>
            </div>

            <h3 className="font-display font-bold text-maroon mb-4">Your Showcase</h3>
            {products.filter(p => p.artisanId === user?.uid).length === 0 ? (
               <div className="flex flex-col items-center justify-center py-12 text-center opacity-50">
                <Store className="w-16 h-16 text-zinc-300 mb-4" />
                <p className="text-sm">You haven't uploaded any products yet.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {products.filter(p => p.artisanId === user?.uid).map(p => (
                  <ProductCard key={p.id} product={p} onClick={() => {}} />
                ))}
              </div>
            )}

            <button 
              onClick={() => setView('upload')}
              className="fixed bottom-12 right-6 w-16 h-16 bg-primary text-white rounded-[24px] shadow-lg flex items-center justify-center active:scale-95 transition-all z-20"
            >
              <Plus className="w-8 h-8" />
            </button>
          </div>
        )}

        {view === 'upload' && (
          <div className="min-h-screen bg-white">
            <header className="fixed top-0 left-0 right-0 p-6 flex items-center gap-4 bg-white/80 backdrop-blur-md z-30">
               <button onClick={() => setView('artisan_home')} className="p-2 -ml-2"><ArrowLeft className="w-5 h-5" /></button>
               <h1 className="text-xl font-display font-bold">Upload Product</h1>
            </header>

            <form onSubmit={handleUpload} className="p-6 pt-24 space-y-6">
              <div 
                onClick={() => document.getElementById('image-input')?.click()}
                className="w-full aspect-video bg-zinc-50 rounded-3xl border-2 border-dashed border-zinc-200 flex flex-col items-center justify-center gap-2 cursor-pointer active:bg-zinc-100 transition-all text-zinc-400 overflow-hidden relative"
              >
                {previewImage ? (
                  <img src={previewImage} alt="Preview" className="w-full h-full object-cover" />
                ) : (
                  <>
                    <Camera className="w-10 h-10" />
                    <span className="text-xs font-medium">Add Product Image</span>
                  </>
                )}
                <input 
                  id="image-input" 
                  type="file" 
                  accept="image/*" 
                  className="hidden" 
                  onChange={handleImageChange} 
                />
              </div>

              <div>
                <label className="text-xs font-bold text-maroon uppercase tracking-wider block mb-2">Product Name</label>
                <input name="name" required placeholder="e.g. Handcrafted Terracotta Pot" className="w-full input-field" />
              </div>

              <div>
                <label className="text-xs font-bold text-maroon uppercase tracking-wider block mb-2">Category</label>
                <select name="category" required className="w-full input-field appearance-none bg-white">
                   {CATEGORIES.map(cat => <option key={cat.id} value={cat.id}>{cat.name}</option>)}
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-maroon uppercase tracking-wider block mb-2">Price (INR)</label>
                <input name="price" type="number" required placeholder="0" className="w-full input-field" />
              </div>

              <div>
                 <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold text-maroon uppercase tracking-wider">Description</label>
                    <button 
                      type="button" 
                      onClick={async () => {
                        const name = (document.querySelector('input[name="name"]') as HTMLInputElement).value;
                        const cat = (document.querySelector('select[name="category"]') as HTMLSelectElement).value;
                        if (name) {
                          const desc = await generateProductDescription(name, cat);
                          const area = document.querySelector('textarea[name="description"]') as HTMLTextAreaElement;
                          if (area) area.value = desc;
                        }
                      }}
                      className="text-[10px] text-primary font-bold flex items-center gap-1"
                    >
                      ✨ AI Generate
                    </button>
                 </div>
                <textarea name="description" rows={4} placeholder="Describe your masterpiece..." className="w-full input-field resize-none" />
              </div>

              <div className="pt-4">
                <button 
                  disabled={isUploading}
                  className="w-full btn-primary flex items-center justify-center gap-2"
                >
                  {isUploading ? "Uploading..." : <><CheckCircle2 className="w-5 h-5" /> Publish Product</>}
                </button>
              </div>
            </form>
          </div>
        )}

        {view === 'product_detail' && selectedProduct && (
          <div className="min-h-screen bg-white">
            <motion.div 
              layoutId={`card-${selectedProduct.id}`}
              className="relative aspect-square"
            >
              <img 
                src={selectedProduct.imageUrl} 
                alt={selectedProduct.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <button 
                onClick={() => setView('buyer_home')}
                className="absolute top-6 left-6 w-10 h-10 bg-white/80 backdrop-blur-md rounded-full flex items-center justify-center shadow-lg active:scale-95 transition-all"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            </motion.div>

            <div className="p-6 -mt-8 bg-white rounded-t-[40px] relative z-10">
              <div className="w-12 h-1 bg-zinc-100 rounded-full mx-auto mb-6" />
              
              <div className="flex items-start justify-between mb-2">
                 <h1 className="text-2xl font-display font-bold text-maroon">{selectedProduct.name}</h1>
                 <span className="text-xl font-bold text-primary">{formatCurrency(selectedProduct.price)}</span>
              </div>

              <div className="flex items-center gap-2 mb-6">
                <span className="px-3 py-1 bg-accent/10 text-accent text-[10px] font-bold rounded-full uppercase tracking-widest">{selectedProduct.category}</span>
                <span className="text-zinc-300">•</span>
                <span className="text-zinc-500 text-xs">Available In Stock</span>
              </div>

              <div className="market-card bg-background/50 flex items-center gap-4 mb-8">
                 <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-white shadow-sm">
                    <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${selectedProduct.artisanName}`} alt="Artisan" />
                 </div>
                 <div className="flex-1">
                    <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">Handcrafted by</p>
                    <h3 className="font-bold text-zinc-800">{selectedProduct.artisanName}</h3>
                 </div>
                 <button className="p-2 bg-white rounded-xl shadow-sm text-accent"><Phone className="w-4 h-4" /></button>
              </div>

              <div className="space-y-4 mb-32">
                 <h4 className="font-bold text-zinc-800">About the Product</h4>
                 <p className="text-zinc-600 text-sm leading-relaxed">{selectedProduct.description}</p>
              </div>

              <div className="fixed bottom-0 left-0 right-0 p-6 glass-nav flex gap-3">
                 <button className="flex-1 btn-primary py-4 flex items-center justify-center gap-2">
                    <MessageCircle className="w-5 h-5" /> Check Stock
                 </button>
                 <div className="w-14 h-14 bg-accent/10 text-accent rounded-2xl flex items-center justify-center">
                    <ShoppingBag className="w-6 h-6" />
                 </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Navigation for Buyer/Artisan (Simulated Android Nav Bar) */}
      {(view === 'buyer_home' || view === 'artisan_home') && (
        <nav className="fixed bottom-0 left-0 right-0 h-20 glass-nav flex items-center justify-around px-8 z-10 max-w-md mx-auto">
          <button 
            className="flex flex-col items-center gap-1 text-primary"
            onClick={() => setView(user?.role === 'artisan' ? 'artisan_home' : 'buyer_home')}
          >
            <div className="relative">
              <Store className="w-6 h-6" />
              <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-primary rounded-full"></div>
            </div>
            <span className="text-[10px] font-bold">HOME</span>
          </button>
          
          <div 
            className="w-14 h-14 bg-maroon rounded-full -mt-10 flex items-center justify-center text-white shadow-lg shadow-maroon/20 active:scale-95 transition-all"
            onClick={() => {
               if (user?.role === 'artisan') setView('upload');
            }}
          >
            <Plus className="w-7 h-7" />
          </div>

          <button className="flex flex-col items-center gap-1 text-zinc-400">
            <UserIcon className="w-6 h-6" />
            <span className="text-[10px] font-bold">PROFILE</span>
          </button>
        </nav>
      )}
    </div>
  );
}
