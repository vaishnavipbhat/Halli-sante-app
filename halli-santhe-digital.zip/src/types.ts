export type UserRole = 'artisan' | 'buyer';

export interface UserProfile {
  uid: string;
  email: string;
  role: UserRole;
  displayName: string;
  phone: string;
  createdAt: number;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  category: string;
  price: number;
  imageUrl: string;
  artisanId: string;
  artisanName: string;
  artisanPhone: string;
  status: 'available' | 'out_of_stock';
  createdAt: number;
}

export type Category = {
  id: string;
  name: string;
  icon: string;
};

export const CATEGORIES: Category[] = [
  { id: 'pottery', name: 'Pottery', icon: '🏺' },
  { id: 'textiles', name: 'Textiles', icon: '🧵' },
  { id: 'woodwork', name: 'Woodwork', icon: '🪑' },
  { id: 'jewelry', name: 'Jewelry', icon: '💍' },
  { id: 'paintings', name: 'Art', icon: '🎨' },
  { id: 'other', name: 'Other', icon: '📦' }
];
