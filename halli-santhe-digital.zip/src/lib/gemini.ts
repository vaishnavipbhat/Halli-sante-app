import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function generateProductDescription(productName: string, category: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate a short, poetic, and attractive marketing description for a handmade local village product named "${productName}" in the category "${category}". Focus on its artisan roots, tradition, and quality. Keep it under 50 words.`,
      config: {
        systemInstruction: "You are an expert marketing copywriter for local Indian village handicrafts. Your tone is warm, inviting, and celebrates local culture.",
      }
    });

    return response.text || "";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Handcrafted with love by our local artisans.";
  }
}
